console.log('Art Gallery App Loaded');
